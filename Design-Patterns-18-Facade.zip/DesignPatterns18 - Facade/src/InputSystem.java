/*
 * Dummy implementation
 */

public class InputSystem {
	public void getInput() {
		System.out.println("Getting input ...");
	}
}
