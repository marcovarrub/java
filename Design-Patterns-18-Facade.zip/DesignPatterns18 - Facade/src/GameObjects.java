/*
 * Dummy implementation
 */
public class GameObjects {
	public void update(InputSystem userInput) {
		System.out.println("Updating positions of game objects...");
	}
}
